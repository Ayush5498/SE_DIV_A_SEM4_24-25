import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Get the correct storage key based on the project URL
const getStorageKey = () => `sb-${supabaseUrl.split('//')[1].split('.')[0]}-auth-token`;

// Enhanced session validation with more robust checks
const isValidSession = (session: string | null): boolean => {
  if (!session) return false;
  try {
    const parsed = JSON.parse(session);
    return !!(
      parsed?.access_token &&
      parsed?.refresh_token &&
      parsed?.expires_at &&
      parsed?.user?.id &&
      parsed?.user?.aud === 'authenticated' &&
      parsed?.expires_at > (Date.now() / 1000)
    );
  } catch (error) {
    console.error('Error validating session:', error);
    return false;
  }
};

// Enhanced storage cleanup
const clearStorage = () => {
  try {
    const storageKey = getStorageKey();
    Object.keys(localStorage).forEach(key => {
      if (key.startsWith('sb-')) {
        localStorage.removeItem(key);
      }
    });
    console.log('Storage cleared successfully');
  } catch (error) {
    console.error('Error clearing storage:', error);
  }
};

// Enhanced session management
const sessionManager = {
  getSession: () => {
    try {
      const storageKey = getStorageKey();
      const session = localStorage.getItem(storageKey);
      return isValidSession(session) ? session : null;
    } catch (error) {
      console.error('Error getting session:', error);
      return null;
    }
  },
  
  setSession: (session: string) => {
    try {
      const storageKey = getStorageKey();
      localStorage.setItem(storageKey, session);
    } catch (error) {
      console.error('Error setting session:', error);
    }
  },
  
  clearSession: () => {
    clearStorage();
  }
};

// Clear invalid session data before creating the client
if (!sessionManager.getSession()) {
  sessionManager.clearSession();
}

// Create Supabase client with enhanced configuration
export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    storageKey: getStorageKey(),
    storage: {
      getItem: (key: string) => {
        try {
          const item = localStorage.getItem(key);
          if (!item || !isValidSession(item)) {
            localStorage.removeItem(key);
            return null;
          }
          return item;
        } catch (error) {
          console.error('Error getting storage item:', error);
          return null;
        }
      },
      setItem: (key: string, value: string) => {
        try {
          localStorage.setItem(key, value);
        } catch (error) {
          console.error('Error setting storage item:', error);
        }
      },
      removeItem: (key: string) => {
        try {
          localStorage.removeItem(key);
        } catch (error) {
          console.error('Error removing storage item:', error);
        }
      }
    }
  },
  global: {
    headers: {
      'Cache-Control': 'no-cache'
    }
  }
});

// Enhanced auth state change listener
supabase.auth.onAuthStateChange(async (event, session) => {
  console.log('Auth state changed:', event, !!session);

  switch (event) {
    case 'SIGNED_OUT':
      sessionManager.clearSession();
      break;
      
    case 'TOKEN_REFRESHED':
      if (!session) {
        sessionManager.clearSession();
      }
      break;
      
    case 'SIGNED_IN':
      if (session) {
        // Ensure we have a valid session after sign in
        const { data: { session: refreshedSession }, error } = await supabase.auth.refreshSession();
        if (error || !refreshedSession) {
          console.error('Error refreshing session after sign in:', error);
          sessionManager.clearSession();
        }
      }
      break;
  }
});

// Periodic session check (every 5 minutes)
setInterval(async () => {
  const session = await supabase.auth.getSession();
  if (session.error || !session.data.session) {
    sessionManager.clearSession();
  }
}, 300000);

// Export utility functions
export const auth = {
  refreshSession: async () => {
    try {
      const { data: { session }, error } = await supabase.auth.refreshSession();
      if (error) throw error;
      return session;
    } catch (error) {
      console.error('Error refreshing session:', error);
      sessionManager.clearSession();
      return null;
    }
  },
  
  getSession: async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;
      return session;
    } catch (error) {
      console.error('Error getting session:', error);
      return null;
    }
  },
  
  signOut: async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      sessionManager.clearSession();
    } catch (error) {
      console.error('Error signing out:', error);
      // Force clear session even if sign out fails
      sessionManager.clearSession();
    }
  }
};