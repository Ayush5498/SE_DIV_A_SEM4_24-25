export interface Profile {
  full_name: string;
  blood_type: string;
  allergies: string[];
  medical_conditions: string[];
  medications: string[];
  emergency_contact_name: string;
  emergency_contact_number: string;
}

export interface Driver {
  id: string;
  full_name: string;
  phone_number: string;
  license_number: string;
  vehicle_number: string;
  is_available: boolean;
  current_location_lat: number | null;
  current_location_lng: number | null;
  created_at: string;
  updated_at: string;
}

export interface EmergencyTask {
  id: string;
  patient_id: string;
  driver_id: string | null;
  status: 'pending' | 'accepted' | 'completed' | 'cancelled';
  patient_location_lat: number;
  patient_location_lng: number;
  created_at: string;
  updated_at: string;
}

export interface EmergencyPayload {
  userId: string;
  location: {
    latitude: number;
    longitude: number;
  };
  profile: Profile;
}

export interface EmergencyHistory {
  id: string;
  user_id: string;
  timestamp: string;
  latitude: number;
  longitude: number;
  created_at: string;
}