import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { EmergencyHistory } from '../lib/types';
import { History } from 'lucide-react';

interface EmergencyHistoryProps {
  userId: string;
}

export default function EmergencyHistory({ userId }: EmergencyHistoryProps) {
  const [history, setHistory] = useState<EmergencyHistory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHistory();
  }, [userId]);

  const fetchHistory = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('emergency_history')
        .select('*')
        .eq('user_id', userId)
        .order('timestamp', { ascending: false });

      if (error) throw error;
      setHistory(data || []);
    } catch (error: any) {
      console.error('Error fetching history:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const openLocation = (latitude: number, longitude: number) => {
    window.open(`https://www.google.com/maps?q=${latitude},${longitude}`, '_blank');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-bold mb-4 flex items-center">
        <History className="w-5 h-5 mr-2" />
        Emergency History
      </h2>
      
      {history.length === 0 ? (
        <p className="text-gray-500 text-center py-4">No emergency alerts have been triggered yet.</p>
      ) : (
        <div className="space-y-4">
          {history.map((record) => (
            <div
              key={record.id}
              className="border rounded-lg p-4 hover:bg-gray-50 transition cursor-pointer"
              onClick={() => openLocation(record.latitude, record.longitude)}
            >
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-semibold">{formatDate(record.timestamp)}</p>
                  <p className="text-sm text-gray-500">
                    Location: {record.latitude.toFixed(6)}, {record.longitude.toFixed(6)}
                  </p>
                </div>
                <button
                  className="text-blue-600 hover:text-blue-800 text-sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    openLocation(record.latitude, record.longitude);
                  }}
                >
                  View on Map
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}