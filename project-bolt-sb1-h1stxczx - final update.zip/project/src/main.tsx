import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, useSearchParams } from 'react-router-dom';
import App from './App.tsx';
import DriverApp from './DriverApp.tsx';
import './index.css';

function Root() {
  const [searchParams] = useSearchParams();
  const isDriver = searchParams.get('driver') === 'true';

  return isDriver ? <DriverApp /> : <App />;
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <Root />
    </BrowserRouter>
  </StrictMode>
);