import React, { useEffect, useState } from 'react';
import { LogOut, MapPin, CheckCircle } from 'lucide-react';
import { supabase, auth } from './lib/supabase';
import type { Driver, EmergencyTask } from './lib/types';
import AuthForm from './components/AuthForm';
import toast, { Toaster } from 'react-hot-toast';

function DriverApp() {
  const [session, setSession] = useState(null);
  const [driver, setDriver] = useState<Driver | null>(null);
  const [tasks, setTasks] = useState<EmergencyTask[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) {
        fetchDriver(session.user.id);
        subscribeToTasks();
      } else {
        setLoading(false);
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) {
        fetchDriver(session.user.id);
      } else {
        setDriver(null);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchDriver = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('drivers')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) throw error;
      setDriver(data);
    } catch (error) {
      console.error('Error fetching driver:', error);
    } finally {
      setLoading(false);
    }
  };

  const subscribeToTasks = () => {
    const tasksSubscription = supabase
      .channel('emergency_tasks')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'emergency_tasks',
        },
        (payload) => {
          if (payload.new) {
            // Show notification for new tasks
            if (payload.eventType === 'INSERT' && payload.new.status === 'pending') {
              toast.custom((t) => (
                <div
                  className={`${
                    t.visible ? 'animate-enter' : 'animate-leave'
                  } max-w-md w-full bg-white shadow-lg rounded-lg pointer-events-auto flex ring-1 ring-black ring-opacity-5`}
                >
                  <div className="flex-1 w-0 p-4">
                    <div className="flex items-start">
                      <div className="ml-3 flex-1">
                        <p className="text-sm font-medium text-gray-900">
                          New Emergency Alert!
                        </p>
                        <p className="mt-1 text-sm text-gray-500">
                          A patient needs immediate assistance.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex border-l border-gray-200">
                    <button
                      onClick={() => {
                        acceptTask(payload.new.id);
                        toast.dismiss(t.id);
                      }}
                      className="w-full border border-transparent rounded-none rounded-r-lg p-4 flex items-center justify-center text-sm font-medium text-blue-600 hover:text-blue-500 focus:outline-none"
                    >
                      Accept
                    </button>
                  </div>
                </div>
              ));
            }
            fetchTasks();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(tasksSubscription);
    };
  };

  const fetchTasks = async () => {
    try {
      const { data, error } = await supabase
        .from('emergency_tasks')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTasks(data || []);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  const acceptTask = async (taskId: string) => {
    try {
      const { error } = await supabase
        .from('emergency_tasks')
        .update({
          driver_id: session?.user.id,
          status: 'accepted',
        })
        .eq('id', taskId);

      if (error) throw error;
      toast.success('Task accepted successfully!');
    } catch (error) {
      console.error('Error accepting task:', error);
      toast.error('Failed to accept task. Please try again.');
    }
  };

  const completeTask = async (taskId: string) => {
    try {
      const { error } = await supabase
        .from('emergency_tasks')
        .update({
          status: 'completed',
        })
        .eq('id', taskId);

      if (error) throw error;
      toast.success('Task completed successfully!');
    } catch (error) {
      console.error('Error completing task:', error);
      toast.error('Failed to complete task. Please try again.');
    }
  };

  const updateLocation = async (position: GeolocationPosition) => {
    if (!session) return;

    try {
      const { error } = await supabase
        .from('drivers')
        .update({
          current_location_lat: position.coords.latitude,
          current_location_lng: position.coords.longitude,
        })
        .eq('id', session.user.id);

      if (error) throw error;
    } catch (error) {
      console.error('Error updating location:', error);
    }
  };

  useEffect(() => {
    if (session) {
      // Watch location changes
      const watchId = navigator.geolocation.watchPosition(
        updateLocation,
        (error) => console.error('Error watching location:', error),
        { enableHighAccuracy: true }
      );

      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, [session]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!session) {
    return <AuthForm />;
  }

  if (!driver) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full space-y-8 p-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Complete Your Profile</h2>
            <p className="text-gray-600">Please set up your driver profile to continue.</p>
          </div>
          {/* Add driver profile setup form here */}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-center" />
      
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-xl font-semibold text-gray-900">HelpMedico 24x7 - Driver Portal</h1>
          <div className="flex items-center space-x-4">
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
              driver.is_available ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              {driver.is_available ? 'Available' : 'Busy'}
            </span>
            <button
              onClick={async () => {
                await auth.signOut();
                window.location.reload();
              }}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
              title="Sign Out"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          {/* Driver Information */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-bold mb-4">Driver Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Full Name</label>
                <p className="text-gray-900">{driver.full_name}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Phone Number</label>
                <p className="text-gray-900">{driver.phone_number}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">License Number</label>
                <p className="text-gray-900">{driver.license_number}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Vehicle Number</label>
                <p className="text-gray-900">{driver.vehicle_number}</p>
              </div>
            </div>
          </div>

          {/* Emergency Tasks */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-bold mb-4">Emergency Tasks</h2>
            <div className="space-y-4">
              {tasks.length === 0 ? (
                <p className="text-gray-500 text-center py-4">No emergency tasks available.</p>
              ) : (
                tasks.map((task) => (
                  <div
                    key={task.id}
                    className="border rounded-lg p-4 hover:bg-gray-50 transition"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              task.status === 'pending'
                                ? 'bg-yellow-100 text-yellow-800'
                                : task.status === 'accepted'
                                ? 'bg-blue-100 text-blue-800'
                                : task.status === 'completed'
                                ? 'bg-green-100 text-green-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {task.status.charAt(0).toUpperCase() + task.status.slice(1)}
                          </span>
                        </div>
                        <p className="text-sm text-gray-500 mt-1">
                          Created: {new Date(task.created_at).toLocaleString()}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        {task.status === 'pending' && (
                          <button
                            onClick={() => acceptTask(task.id)}
                            className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Accept
                          </button>
                        )}
                        {task.status === 'accepted' && task.driver_id === session.user.id && (
                          <button
                            onClick={() => completeTask(task.id)}
                            className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Complete
                          </button>
                        )}
                        <button
                          onClick={() => {
                            const url = `https://www.google.com/maps?q=${task.patient_location_lat},${task.patient_location_lng}`;
                            window.open(url, '_blank');
                          }}
                          className="inline-flex items-center px-3 py-1 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                        >
                          <MapPin className="w-4 h-4 mr-1" />
                          View Location
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default DriverApp;