import React, { useEffect, useState } from 'react';
import { LogOut, AlertTriangle } from 'lucide-react';
import { supabase, auth } from './lib/supabase';
import type { Profile } from './lib/types';
import EmergencyHistory from './components/EmergencyHistory';
import AuthForm from './components/AuthForm';
import toast, { Toaster } from 'react-hot-toast';

function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) {
        fetchProfile(session.user.id);
      } else {
        setLoading(false);
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) {
        fetchProfile(session.user.id);
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) throw error;
      setProfile(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const triggerEmergency = async () => {
    if (!session || !profile) return;

    try {
      // Get current location
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject);
      });

      const { latitude, longitude } = position.coords;

      // Save to emergency history
      const { error: historyError } = await supabase
        .from('emergency_history')
        .insert({
          user_id: session.user.id,
          latitude,
          longitude,
        });

      if (historyError) throw historyError;

      // Create emergency task
      const { error: taskError } = await supabase
        .from('emergency_tasks')
        .insert({
          patient_id: session.user.id,
          patient_location_lat: latitude,
          patient_location_lng: longitude,
          status: 'pending',
        });

      if (taskError) throw taskError;

      toast.success('Emergency alert sent successfully!');
    } catch (error) {
      console.error('Error triggering emergency:', error);
      toast.error('Failed to send emergency alert. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!session) {
    return <AuthForm />;
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full space-y-8 p-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Complete Your Profile</h2>
            <p className="text-gray-600">Please set up your medical profile to continue.</p>
          </div>
          {/* Add profile setup form here */}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-center" />
      
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-xl font-semibold text-gray-900">HelpMedico 24x7</h1>
          <button
            onClick={async () => {
              await auth.signOut();
              window.location.reload();
            }}
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-full transition-colors"
            title="Sign Out"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Emergency Button */}
          <div className="bg-white rounded-lg shadow-lg p-6 flex flex-col items-center justify-center">
            <button
              onClick={triggerEmergency}
              className="w-48 h-48 rounded-full bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-4 focus:ring-red-300 flex items-center justify-center text-white transition-colors"
            >
              <div className="text-center">
                <AlertTriangle className="w-16 h-16 mx-auto mb-2" />
                <span className="text-lg font-semibold">Emergency</span>
              </div>
            </button>
            <p className="mt-4 text-gray-600 text-center">
              Press the button to alert nearby emergency services
            </p>
          </div>

          {/* Profile Information */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-bold mb-4">Medical Profile</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Full Name</label>
                <p className="text-gray-900">{profile.full_name}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Blood Type</label>
                <p className="text-gray-900">{profile.blood_type || 'Not specified'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Allergies</label>
                <p className="text-gray-900">
                  {profile.allergies?.length ? profile.allergies.join(', ') : 'None'}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Medical Conditions</label>
                <p className="text-gray-900">
                  {profile.medical_conditions?.length
                    ? profile.medical_conditions.join(', ')
                    : 'None'}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Current Medications</label>
                <p className="text-gray-900">
                  {profile.medications?.length ? profile.medications.join(', ') : 'None'}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Emergency Contact</label>
                <p className="text-gray-900">
                  {profile.emergency_contact_name} ({profile.emergency_contact_number})
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Emergency History */}
        <div className="mt-8">
          <EmergencyHistory userId={session.user.id} />
        </div>
      </main>
    </div>
  );
}

export default App;