export interface Profile {
  full_name: string;
  blood_type: string;
  allergies: string[];
  medical_conditions: string[];
  medications: string[];
  emergency_contact_name: string;
  emergency_contact_number: string;
}

export interface EmergencyPayload {
  userId: string;
  location: {
    latitude: number;
    longitude: number;
  };
  profile: Profile;
}