import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { corsHeaders } from '../_shared/cors.ts'
import { EmergencyPayload } from '../_shared/types.ts'

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Validate request method
    if (req.method !== 'POST') {
      throw new Error('Method not allowed')
    }

    // Parse and validate request body
    const payload = await req.json() as EmergencyPayload
    if (!payload || !payload.userId || !payload.location || !payload.profile) {
      throw new Error('Invalid request payload')
    }

    // For now, we'll just log the emergency alert and return success
    // since we removed Twilio integration
    console.log('Emergency alert received:', {
      userId: payload.userId,
      location: payload.location,
      profile: payload.profile
    })

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Emergency alert processed successfully'
      }),
      {
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json'
        },
        status: 200,
      }
    )
  } catch (error) {
    console.error('Error processing emergency alert:', error)
    
    return new Response(
      JSON.stringify({ 
        success: false,
        error: error.message || 'Unknown error occurred',
        details: 'Failed to process emergency alert'
      }),
      {
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json'
        },
        status: 500,
      }
    )
  }
})