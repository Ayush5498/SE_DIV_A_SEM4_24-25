/*
  # Emergency History Tracking

  1. New Tables
    - `emergency_history`
      - `id` (uuid, primary key)
      - `user_id` (uuid) - References profiles table
      - `timestamp` (timestamptz) - When emergency was triggered
      - `latitude` (double precision) - Location latitude
      - `longitude` (double precision) - Location longitude
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on emergency_history table
    - Add policies for authenticated users to:
      - Insert their own emergency records
      - Read their own emergency history
*/

CREATE TABLE IF NOT EXISTS emergency_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  timestamp timestamptz NOT NULL DEFAULT now(),
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE emergency_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert own emergency history"
  ON emergency_history
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read own emergency history"
  ON emergency_history
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);