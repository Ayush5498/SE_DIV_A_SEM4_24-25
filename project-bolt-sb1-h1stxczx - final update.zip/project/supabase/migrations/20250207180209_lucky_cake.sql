/*
  # Health Emergency Platform Schema

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key) - Links to auth.users
      - `full_name` (text) - User's full name
      - `blood_type` (text) - Blood type
      - `allergies` (text[]) - List of allergies
      - `medical_conditions` (text[]) - List of medical conditions
      - `medications` (text[]) - Current medications
      - `emergency_contact_name` (text) - Emergency contact person
      - `emergency_contact_number` (text) - Emergency contact phone
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
  2. Security
    - Enable RLS on profiles table
    - Add policies for authenticated users to manage their own data
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name text NOT NULL,
  blood_type text,
  allergies text[] DEFAULT '{}',
  medical_conditions text[] DEFAULT '{}',
  medications text[] DEFAULT '{}',
  emergency_contact_name text NOT NULL,
  emergency_contact_number text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);