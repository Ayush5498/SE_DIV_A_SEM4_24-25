/*
  # Ambulance Driver System

  1. New Tables
    - `drivers`
      - `id` (uuid, primary key) - Links to auth.users
      - `full_name` (text) - Driver's full name
      - `phone_number` (text) - Driver's contact number
      - `license_number` (text) - Driver's license number
      - `vehicle_number` (text) - Ambulance vehicle number
      - `is_available` (boolean) - Driver's availability status
      - `current_location_lat` (double precision) - Current latitude
      - `current_location_lng` (double precision) - Current longitude
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `emergency_tasks`
      - `id` (uuid, primary key)
      - `patient_id` (uuid) - References profiles table
      - `driver_id` (uuid) - References drivers table
      - `status` (text) - Task status (pending, accepted, completed, cancelled)
      - `patient_location_lat` (double precision)
      - `patient_location_lng` (double precision)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Add appropriate policies for authenticated users
*/

-- Create drivers table if it doesn't exist
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS drivers (
    id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
    full_name text NOT NULL,
    phone_number text NOT NULL,
    license_number text NOT NULL,
    vehicle_number text NOT NULL,
    is_available boolean DEFAULT true,
    current_location_lat double precision,
    current_location_lng double precision,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
  );
EXCEPTION
  WHEN duplicate_table THEN
    NULL;
END $$;

-- Create emergency tasks table if it doesn't exist
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS emergency_tasks (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
    driver_id uuid REFERENCES drivers(id) ON DELETE CASCADE,
    status text NOT NULL DEFAULT 'pending',
    patient_location_lat double precision NOT NULL,
    patient_location_lng double precision NOT NULL,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    CONSTRAINT valid_status CHECK (status IN ('pending', 'accepted', 'completed', 'cancelled'))
  );
EXCEPTION
  WHEN duplicate_table THEN
    NULL;
END $$;

-- Enable RLS
ALTER TABLE drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_tasks ENABLE ROW LEVEL SECURITY;

-- Policies for drivers table
DO $$ BEGIN
  DROP POLICY IF EXISTS "Drivers can read own profile" ON drivers;
  CREATE POLICY "Drivers can read own profile"
    ON drivers
    FOR SELECT
    TO authenticated
    USING (auth.uid() = id);
END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS "Drivers can insert own profile" ON drivers;
  CREATE POLICY "Drivers can insert own profile"
    ON drivers
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = id);
END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS "Drivers can update own profile" ON drivers;
  CREATE POLICY "Drivers can update own profile"
    ON drivers
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);
END $$;

-- Policies for emergency tasks
DO $$ BEGIN
  DROP POLICY IF EXISTS "Patients can create emergency tasks" ON emergency_tasks;
  CREATE POLICY "Patients can create emergency tasks"
    ON emergency_tasks
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = patient_id);
END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS "Patients can view own tasks" ON emergency_tasks;
  CREATE POLICY "Patients can view own tasks"
    ON emergency_tasks
    FOR SELECT
    TO authenticated
    USING (auth.uid() = patient_id);
END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS "Drivers can view available tasks" ON emergency_tasks;
  CREATE POLICY "Drivers can view available tasks"
    ON emergency_tasks
    FOR SELECT
    TO authenticated
    USING (
      EXISTS (
        SELECT 1 FROM drivers WHERE id = auth.uid()
      )
    );
END $$;

DO $$ BEGIN
  DROP POLICY IF EXISTS "Drivers can update assigned tasks" ON emergency_tasks;
  CREATE POLICY "Drivers can update assigned tasks"
    ON emergency_tasks
    FOR UPDATE
    TO authenticated
    USING (
      driver_id = auth.uid() OR
      (
        status = 'pending' AND
        EXISTS (SELECT 1 FROM drivers WHERE id = auth.uid() AND is_available = true)
      )
    )
    WITH CHECK (
      driver_id = auth.uid() OR
      (
        status = 'pending' AND
        EXISTS (SELECT 1 FROM drivers WHERE id = auth.uid() AND is_available = true)
      )
    );
END $$;